# BlueScanner
This Project is based on Bluetooth Low Energy devices.
